The source code files are:
fptree.py
apriori.py
Make sure they are in the same directory while running the program
No other specific instructions.